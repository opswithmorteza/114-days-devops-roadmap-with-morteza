# Day 113 Projects — DevOps Portfolio and Interview Lab

This day has two assessed projects. Full requirements and acceptance criteria are in [the lesson](../notes.md).

1. [Project 1 — Guided build: DevOps Portfolio and Interview Lab](PROJECT-1.md)
2. [Project 2 — Production challenge: DevOps Portfolio and Interview Lab](PROJECT-2.md)

Keep screenshots and command output in a local `evidence/` directory. Redact secrets and personal data before committing.
