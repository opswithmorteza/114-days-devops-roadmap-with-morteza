# Day 074 Projects — Capstone Monitoring

This day has two assessed projects. Full requirements and acceptance criteria are in [the lesson](../notes.md).

1. [Project 1 — Capstone milestone: Capstone Monitoring](PROJECT-1.md)
2. [Project 2 — Failure and review exercise: Capstone Monitoring](PROJECT-2.md)

Keep screenshots and command output in a local `evidence/` directory. Redact secrets and personal data before committing.
