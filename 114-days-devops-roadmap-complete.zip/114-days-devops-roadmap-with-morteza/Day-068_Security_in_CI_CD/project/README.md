# Day 068 Projects — Security in CI/CD

This day has two assessed projects. Full requirements and acceptance criteria are in [the lesson](../notes.md).

1. [Project 1 — Guided build: Security in CI/CD](PROJECT-1.md)
2. [Project 2 — Production challenge: Security in CI/CD](PROJECT-2.md)

Keep screenshots and command output in a local `evidence/` directory. Redact secrets and personal data before committing.
