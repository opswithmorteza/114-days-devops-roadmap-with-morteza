# Day 016 Projects — Virtualization with KVM and libvirt

This day has two assessed projects. Full requirements and acceptance criteria are in [the lesson](../notes.md).

1. [Project 1 — Guided build: Virtualization with KVM and libvirt](PROJECT-1.md)
2. [Project 2 — Production challenge: Virtualization with KVM and libvirt](PROJECT-2.md)

Keep screenshots and command output in a local `evidence/` directory. Redact secrets and personal data before committing.
