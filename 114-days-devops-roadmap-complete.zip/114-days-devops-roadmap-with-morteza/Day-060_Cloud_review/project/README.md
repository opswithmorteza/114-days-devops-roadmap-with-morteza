# Day 060 Projects — Multi-Cloud Review

This day has two assessed projects. Full requirements and acceptance criteria are in [the lesson](../notes.md).

1. [Project 1 — Guided build: Multi-Cloud Review](PROJECT-1.md)
2. [Project 2 — Production challenge: Multi-Cloud Review](PROJECT-2.md)

Keep screenshots and command output in a local `evidence/` directory. Redact secrets and personal data before committing.
