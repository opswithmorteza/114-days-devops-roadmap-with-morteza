# Day 050 — Kubernetes Deployments and Services

> Track: **Kubernetes packaging and delivery** · Suggested study time: **90–150 minutes**

## Why this matters

Kubernetes Deployments and Services is part of the operational path from a developer commit to a reliable production service. Today's goal is to understand the system, practise the normal workflow, deliberately observe one failure, and leave reproducible evidence in Git.

## Learning outcomes

By the end of the day you should be able to:

- describe replicas and rollouts in plain language;
- use selectors and service discovery in a small working lab;
- validate the result with evidence instead of assuming success;
- recognise one common failure and return safely to the previous state.

## Core ideas

- **replicas** — a runtime building block: it consumes resources, has a lifecycle, and must expose a healthy state. In the lab, observe it before and after one controlled change so the idea is tied to real evidence.
- **rollouts** — an automation mechanism: it moves a declared change through repeatable steps while exposing failures and rollback points. In the lab, observe it before and after one controlled change so the idea is tied to real evidence.
- **selectors** — a core operating concept in Kubernetes Deployments and Services: understand its purpose, inputs, outputs, owner, normal signal, and failure signal. In the lab, observe it before and after one controlled change so the idea is tied to real evidence.
- **service discovery** — part of the request path: it decides how traffic is addressed, transported, filtered, or forwarded. In the lab, observe it before and after one controlled change so the idea is tied to real evidence.

The useful mental model is **desired state → action → observed state → evidence**. Write down what you expect before each change. After the change, check the service from both the operator's view and the user's view. A command returning zero is useful evidence, but a real request, metric, log entry, or restored file is stronger.

## Lab setup and safety

Use kind, minikube, or a disposable Kubernetes cluster. Work in a dedicated namespace and define resource requests so experiments remain contained.

1. Record the starting state and tool versions.
2. Make the smallest possible change.
3. Run a syntax or dry-run check where the tool supports it.
4. Apply the change and observe logs/events while it happens.
5. Test the happy path and one negative path.
6. Revert or clean up, then repeat from the README to prove reproducibility.

## Worked example

Run the following as a starting point, adapting names and addresses to your lab:

```bash
kubectl rollout status deploy/web
kubectl get svc,endpoints
```

Before running privileged or destructive operations, read the help page and confirm the target. Save relevant output in a text file under an `evidence/` directory, but redact tokens, passwords, private keys, public IPs, and personal data.

## Practical workflow

- **Discover:** inspect the current state without modifying it.
- **Plan:** state the intended result, risks, and rollback.
- **Implement:** keep configuration declarative and version-controlled where possible.
- **Verify:** test syntax, behaviour, logs, and the user-facing endpoint.
- **Break safely:** introduce one controlled error related to replicas or selectors.
- **Recover:** use the evidence to diagnose, roll back, and document the root cause.

## Project 1 — Guided build: Kubernetes Deployments and Services

Build a clean lab that demonstrates all four concepts: **replicas**, **rollouts**, **selectors**, **service discovery**.

**Required deliverables**

- a short architecture diagram or request-flow sketch;
- version-controlled configuration or automation;
- a README with prerequisites, exact run steps, validation, and cleanup;
- captured evidence showing a successful result;
- a troubleshooting note for one mistake you actually tested.

**Acceptance test:** another person can start from a clean machine, follow only your README, run the validation command, and get the documented result.

## Project 2 — Production challenge: Kubernetes Deployments and Services

Turn the first lab into an operations exercise. Add automation, deliberately create a failure around **rollouts**, and diagnose it without random changes. Add a health check or measurable signal, a rollback step, and a short incident timeline.

**Definition of done**

- secrets and machine-specific values are not committed;
- repeated execution is safe or its side effects are clearly documented;
- the negative test fails for the expected reason;
- rollback restores the original service;
- cleanup leaves no unexpected process, container, cloud resource, mount, or credential.

## Review questions

1. How would you explain replicas to a developer who has not operated production systems?
2. Which signal proves rollouts is healthy?
3. What is the safest rollback if selectors fails halfway through?
4. Which part should be automated next, and what new risk would that automation introduce?

## Completion checklist

- [ ] I can explain the four core ideas without reading the notes.
- [ ] I ran the worked example and saved redacted evidence.
- [ ] Project 1 passes from a clean start.
- [ ] Project 2 includes failure, diagnosis, recovery, and cleanup.
- [ ] I committed notes using a meaningful message and linked the evidence.

## Further reading

- Use the official documentation for the named tool or service as the source of truth.
- Use local manual pages (`man`, `--help`) for the exact installed version.
- Re-check cloud pricing, security guidance, and release notes before using the lab in production.
