# Day 085 Projects — Personal Branding for DevOps

This day has two assessed projects. Full requirements and acceptance criteria are in [the lesson](../notes.md).

1. [Project 1 — Build an evidence-led DevOps profile](PROJECT-1.md)
2. [Project 2 — Create a four-week publishing system](PROJECT-2.md)

Keep screenshots and command output in a local `evidence/` directory. Redact secrets and personal data before committing.
