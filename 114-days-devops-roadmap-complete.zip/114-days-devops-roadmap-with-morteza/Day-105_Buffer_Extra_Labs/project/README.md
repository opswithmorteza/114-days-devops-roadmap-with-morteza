# Day 105 Projects — Policy as Code with OPA

This day has two assessed projects. Full requirements and acceptance criteria are in [the lesson](../notes.md).

1. [Project 1 — Guided build: Policy as Code with OPA](PROJECT-1.md)
2. [Project 2 — Production challenge: Policy as Code with OPA](PROJECT-2.md)

Keep screenshots and command output in a local `evidence/` directory. Redact secrets and personal data before committing.
