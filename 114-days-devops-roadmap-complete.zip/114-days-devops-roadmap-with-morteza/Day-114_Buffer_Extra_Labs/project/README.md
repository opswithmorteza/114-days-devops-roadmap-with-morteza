# Day 114 Projects — Production Readiness Review and Graduation

This day has two assessed projects. Full requirements and acceptance criteria are in [the lesson](../notes.md).

1. [Project 1 — Production readiness assessment](PROJECT-1.md)
2. [Project 2 — Graduation incident simulation](PROJECT-2.md)

Keep screenshots and command output in a local `evidence/` directory. Redact secrets and personal data before committing.
