# Day 040 Projects — Jenkins Advanced: Agents and Stages

This day has two assessed projects. Full requirements and acceptance criteria are in [the lesson](../notes.md).

1. [Project 1 — Guided build: Jenkins Advanced: Agents and Stages](PROJECT-1.md)
2. [Project 2 — Production challenge: Jenkins Advanced: Agents and Stages](PROJECT-2.md)

Keep screenshots and command output in a local `evidence/` directory. Redact secrets and personal data before committing.
