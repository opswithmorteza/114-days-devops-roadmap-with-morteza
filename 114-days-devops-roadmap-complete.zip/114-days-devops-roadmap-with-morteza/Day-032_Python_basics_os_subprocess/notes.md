# Day 032 — Python Automation: os and subprocess

> Track: **automation and source control** · Suggested study time: **90–150 minutes**

## Why this matters

Python Automation: os and subprocess is part of the operational path from a developer commit to a reliable production service. Today's goal is to understand the system, practise the normal workflow, deliberately observe one failure, and leave reproducible evidence in Git.

## Learning outcomes

By the end of the day you should be able to:

- describe filesystem APIs and process execution in plain language;
- use errors and structured output in a small working lab;
- validate the result with evidence instead of assuming success;
- recognise one common failure and return safely to the previous state.

## Core ideas

- **filesystem APIs** — a data-lifecycle mechanism: it controls where data lives, how it survives restarts, and how it is recovered. In the lab, observe it before and after one controlled change so the idea is tied to real evidence.
- **process execution** — a runtime building block: it consumes resources, has a lifecycle, and must expose a healthy state. In the lab, observe it before and after one controlled change so the idea is tied to real evidence.
- **errors** — a core operating concept in Python Automation: os and subprocess: understand its purpose, inputs, outputs, owner, normal signal, and failure signal. In the lab, observe it before and after one controlled change so the idea is tied to real evidence.
- **structured output** — a declarative contract: it records intent so a tool or service can compare, validate, and enforce the required state. In the lab, observe it before and after one controlled change so the idea is tied to real evidence.

The useful mental model is **desired state → action → observed state → evidence**. Write down what you expect before each change. After the change, check the service from both the operator's view and the user's view. A command returning zero is useful evidence, but a real request, metric, log entry, or restored file is stronger.

## Lab setup and safety

Use a small Git repository containing scripts and tests. Never put credentials in the repository; use environment variables and ignored local files.

1. Record the starting state and tool versions.
2. Make the smallest possible change.
3. Run a syntax or dry-run check where the tool supports it.
4. Apply the change and observe logs/events while it happens.
5. Test the happy path and one negative path.
6. Revert or clean up, then repeat from the README to prove reproducibility.

## Worked example

Run the following as a starting point, adapting names and addresses to your lab:

```bash
python -c "import subprocess
print(subprocess.run(['uname','-a'],capture_output=True,text=True).stdout)"
```

Before running privileged or destructive operations, read the help page and confirm the target. Save relevant output in a text file under an `evidence/` directory, but redact tokens, passwords, private keys, public IPs, and personal data.

## Practical workflow

- **Discover:** inspect the current state without modifying it.
- **Plan:** state the intended result, risks, and rollback.
- **Implement:** keep configuration declarative and version-controlled where possible.
- **Verify:** test syntax, behaviour, logs, and the user-facing endpoint.
- **Break safely:** introduce one controlled error related to filesystem APIs or errors.
- **Recover:** use the evidence to diagnose, roll back, and document the root cause.

## Project 1 — Guided build: Python Automation: os and subprocess

Build a clean lab that demonstrates all four concepts: **filesystem APIs**, **process execution**, **errors**, **structured output**.

**Required deliverables**

- a short architecture diagram or request-flow sketch;
- version-controlled configuration or automation;
- a README with prerequisites, exact run steps, validation, and cleanup;
- captured evidence showing a successful result;
- a troubleshooting note for one mistake you actually tested.

**Acceptance test:** another person can start from a clean machine, follow only your README, run the validation command, and get the documented result.

## Project 2 — Production challenge: Python Automation: os and subprocess

Turn the first lab into an operations exercise. Add automation, deliberately create a failure around **process execution**, and diagnose it without random changes. Add a health check or measurable signal, a rollback step, and a short incident timeline.

**Definition of done**

- secrets and machine-specific values are not committed;
- repeated execution is safe or its side effects are clearly documented;
- the negative test fails for the expected reason;
- rollback restores the original service;
- cleanup leaves no unexpected process, container, cloud resource, mount, or credential.

## Review questions

1. How would you explain filesystem APIs to a developer who has not operated production systems?
2. Which signal proves process execution is healthy?
3. What is the safest rollback if errors fails halfway through?
4. Which part should be automated next, and what new risk would that automation introduce?

## Completion checklist

- [ ] I can explain the four core ideas without reading the notes.
- [ ] I ran the worked example and saved redacted evidence.
- [ ] Project 1 passes from a clean start.
- [ ] Project 2 includes failure, diagnosis, recovery, and cleanup.
- [ ] I committed notes using a meaningful message and linked the evidence.

## Further reading

- Use the official documentation for the named tool or service as the source of truth.
- Use local manual pages (`man`, `--help`) for the exact installed version.
- Re-check cloud pricing, security guidance, and release notes before using the lab in production.
