# Day 021 Projects — DHCP and PXE

This day has two assessed projects. Full requirements and acceptance criteria are in [the lesson](../notes.md).

1. [Project 1 — Guided build: DHCP and PXE](PROJECT-1.md)
2. [Project 2 — Production challenge: DHCP and PXE](PROJECT-2.md)

Keep screenshots and command output in a local `evidence/` directory. Redact secrets and personal data before committing.
