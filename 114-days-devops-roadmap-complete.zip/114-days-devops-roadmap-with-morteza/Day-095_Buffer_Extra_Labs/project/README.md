# Day 095 Projects — SLOs, SLIs and Error Budgets

This day has two assessed projects. Full requirements and acceptance criteria are in [the lesson](../notes.md).

1. [Project 1 — Guided build: SLOs, SLIs and Error Budgets](PROJECT-1.md)
2. [Project 2 — Production challenge: SLOs, SLIs and Error Budgets](PROJECT-2.md)

Keep screenshots and command output in a local `evidence/` directory. Redact secrets and personal data before committing.
