# Day 005 – Bash scripting II (regex, error handling)

## 🎯 Goals
- Bash scripting II (regex, error handling)

## 🔧 Lab / Project
Log rotation script

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
