# Day 046 – Terraform basics

## 🎯 Goals
- Terraform basics

## 🔧 Lab / Project
Deploy AWS EC2

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
