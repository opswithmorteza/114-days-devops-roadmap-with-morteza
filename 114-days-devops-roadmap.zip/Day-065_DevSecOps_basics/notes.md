# Day 065 – DevSecOps basics

## 🎯 Goals
- DevSecOps basics

## 🔧 Lab / Project
Container image scanning (Trivy)

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
