# Day 022 – LPIC-3: File sharing (NFS/SMB)

## 🎯 Goals
- LPIC-3: File sharing (NFS/SMB)

## 🔧 Lab / Project
NFSv4 export; test from client

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
