# Day 027 – LPIC-3: Enterprise troubleshooting

## 🎯 Goals
- LPIC-3: Enterprise troubleshooting

## 🔧 Lab / Project
Debug DNS/DHCP/LDAP end-to-end

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
