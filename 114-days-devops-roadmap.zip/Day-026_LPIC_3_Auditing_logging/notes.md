# Day 026 – LPIC-3: Auditing & logging

## 🎯 Goals
- LPIC-3: Auditing & logging

## 🔧 Lab / Project
auditd rules; journald filters

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
