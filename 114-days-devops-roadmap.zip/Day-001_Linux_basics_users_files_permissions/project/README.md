# Project – Day 001

Describe the project, steps to run, and expected outcome.
