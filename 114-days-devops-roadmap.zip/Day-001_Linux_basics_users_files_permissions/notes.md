# Day 001 – Linux basics (users, files, permissions)

## 🎯 Goals
- Linux basics (users, files, permissions)

## 🔧 Lab / Project
Setup Linux VM; create users & groups; manage permissions

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
