# Day 073 – Capstone deploy app

## 🎯 Goals
- Capstone deploy app

## 🔧 Lab / Project
K8s + Helm

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
