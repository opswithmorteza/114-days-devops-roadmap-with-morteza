# Day 008 – Web server setup (nginx/apache)

## 🎯 Goals
- Web server setup (nginx/apache)

## 🔧 Lab / Project
Deploy a static site on nginx

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
