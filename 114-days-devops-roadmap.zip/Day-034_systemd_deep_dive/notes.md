# Day 034 – systemd deep dive

## 🎯 Goals
- systemd deep dive

## 🔧 Lab / Project
Service watchdog/auto-restart

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
