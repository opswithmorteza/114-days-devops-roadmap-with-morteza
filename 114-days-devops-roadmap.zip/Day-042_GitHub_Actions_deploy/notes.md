# Day 042 – GitHub Actions deploy

## 🎯 Goals
- GitHub Actions deploy

## 🔧 Lab / Project
CD to a VM or container registry

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
