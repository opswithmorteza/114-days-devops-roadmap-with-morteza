# Day 007 – Linux storage (partitions, fstab)

## 🎯 Goals
- Linux storage (partitions, fstab)

## 🔧 Lab / Project
Create & mount partition; configure fstab

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
