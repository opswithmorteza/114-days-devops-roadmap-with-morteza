# Contributing

- Keep each day self-contained (notes + project).
- Prefer English for wider audience.
- Link your sources at the bottom of `notes.md`.
- Use meaningful commit messages: `day-012: add nginx SSL lab`.
