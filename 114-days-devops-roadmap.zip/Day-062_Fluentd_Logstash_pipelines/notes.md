# Day 062 – Fluentd/Logstash pipelines

## 🎯 Goals
- Fluentd/Logstash pipelines

## 🔧 Lab / Project
Collect app & k8s logs

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
