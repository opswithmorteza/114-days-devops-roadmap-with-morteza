# Day 070 – Capstone repos setup

## 🎯 Goals
- Capstone repos setup

## 🔧 Lab / Project
Infra repo skeleton

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
