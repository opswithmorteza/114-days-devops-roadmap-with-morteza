# Day 010 – Advanced networking (DNS resolver)

## 🎯 Goals
- Advanced networking (DNS resolver)

## 🔧 Lab / Project
Local DNS caching resolver

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
