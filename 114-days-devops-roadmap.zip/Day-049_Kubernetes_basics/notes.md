# Day 049 – Kubernetes basics

## 🎯 Goals
- Kubernetes basics

## 🔧 Lab / Project
Deploy app on minikube

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
