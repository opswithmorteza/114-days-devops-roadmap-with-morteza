# Day 032 – Python basics (os, subprocess)

## 🎯 Goals
- Python basics (os, subprocess)

## 🔧 Lab / Project
Log parser tool

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
