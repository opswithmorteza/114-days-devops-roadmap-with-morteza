# Day 066 – HashiCorp Vault basics

## 🎯 Goals
- HashiCorp Vault basics

## 🔧 Lab / Project
KV secrets engine

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
