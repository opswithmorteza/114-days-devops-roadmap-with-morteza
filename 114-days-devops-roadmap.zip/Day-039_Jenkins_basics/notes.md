# Day 039 – Jenkins basics

## 🎯 Goals
- Jenkins basics

## 🔧 Lab / Project
Freestyle → Pipeline migration

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
