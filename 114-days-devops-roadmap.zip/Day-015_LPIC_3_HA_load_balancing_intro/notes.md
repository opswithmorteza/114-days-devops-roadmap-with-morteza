# Day 015 – LPIC-3: HA & load balancing intro

## 🎯 Goals
- LPIC-3: HA & load balancing intro

## 🔧 Lab / Project
2-node HAProxy load balancer (round-robin)

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
