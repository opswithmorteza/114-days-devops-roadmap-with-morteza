# Day 011 – Mail services basics

## 🎯 Goals
- Mail services basics

## 🔧 Lab / Project
Postfix test instance (local mail)

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
