# Day 051 – ConfigMaps & Secrets

## 🎯 Goals
- ConfigMaps & Secrets

## 🔧 Lab / Project
Externalize config & secrets

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
