# Day 114 – Buffer / Extra Labs

## 🎯 Goals
- Buffer / Extra Labs

## 🔧 Lab / Project
Revisit weak topics; deepen a tool of choice

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
