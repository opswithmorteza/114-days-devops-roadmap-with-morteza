# Day 047 – Terraform modules

## 🎯 Goals
- Terraform modules

## 🔧 Lab / Project
Reusable VPC/EC2 module

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
