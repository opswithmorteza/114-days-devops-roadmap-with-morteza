# Day 035 – Docker basics

## 🎯 Goals
- Docker basics

## 🔧 Lab / Project
Dockerize a web app

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
