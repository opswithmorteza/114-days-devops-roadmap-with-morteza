# Day 077 – Capstone testing I

## 🎯 Goals
- Capstone testing I

## 🔧 Lab / Project
Functional tests

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
