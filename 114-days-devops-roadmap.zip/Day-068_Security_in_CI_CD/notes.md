# Day 068 – Security in CI/CD

## 🎯 Goals
- Security in CI/CD

## 🔧 Lab / Project
Add scans to pipeline

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
