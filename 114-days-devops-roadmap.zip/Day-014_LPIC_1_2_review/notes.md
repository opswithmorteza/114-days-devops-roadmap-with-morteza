# Day 014 – LPIC-1/2 review

## 🎯 Goals
- LPIC-1/2 review

## 🔧 Lab / Project
Cheatsheet of key commands

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
