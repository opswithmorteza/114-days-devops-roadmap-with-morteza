# Day 085 – Personal branding

## 🎯 Goals
- Personal branding

## 🔧 Lab / Project
Update LinkedIn & GitHub

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
