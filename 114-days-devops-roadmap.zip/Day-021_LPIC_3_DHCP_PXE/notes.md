# Day 021 – LPIC-3: DHCP + PXE

## 🎯 Goals
- LPIC-3: DHCP + PXE

## 🔧 Lab / Project
PXE boot a VM via DHCP/TFTP

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
