# Day 045 – Ansible Vault & secrets

## 🎯 Goals
- Ansible Vault & secrets

## 🔧 Lab / Project
Encrypt vars; deploy with secrets

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
