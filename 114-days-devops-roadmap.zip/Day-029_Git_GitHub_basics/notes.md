# Day 029 – Git & GitHub basics

## 🎯 Goals
- Git & GitHub basics

## 🔧 Lab / Project
Branching workflow; PR practice

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
