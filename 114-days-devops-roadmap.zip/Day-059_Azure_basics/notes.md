# Day 059 – Azure basics

## 🎯 Goals
- Azure basics

## 🔧 Lab / Project
Create AKS cluster

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
