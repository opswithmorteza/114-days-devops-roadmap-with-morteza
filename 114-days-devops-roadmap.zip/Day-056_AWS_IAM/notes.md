# Day 056 – AWS IAM

## 🎯 Goals
- AWS IAM

## 🔧 Lab / Project
Users, roles, least privilege

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
