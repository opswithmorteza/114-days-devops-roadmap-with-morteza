# Day 023 – LPIC-3: Storage SAN concepts

## 🎯 Goals
- LPIC-3: Storage SAN concepts

## 🔧 Lab / Project
Document iSCSI/SAN design patterns

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
