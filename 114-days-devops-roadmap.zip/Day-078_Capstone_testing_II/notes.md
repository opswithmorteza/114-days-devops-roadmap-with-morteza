# Day 078 – Capstone testing II

## 🎯 Goals
- Capstone testing II

## 🔧 Lab / Project
Performance tests

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
