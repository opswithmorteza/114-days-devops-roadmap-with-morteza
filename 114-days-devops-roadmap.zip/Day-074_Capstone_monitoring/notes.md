# Day 074 – Capstone monitoring

## 🎯 Goals
- Capstone monitoring

## 🔧 Lab / Project
Prometheus + Grafana

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
