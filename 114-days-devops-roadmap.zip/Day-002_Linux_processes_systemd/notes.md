# Day 002 – Linux processes & systemd

## 🎯 Goals
- Linux processes & systemd

## 🔧 Lab / Project
Manage services; write a custom systemd unit

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
