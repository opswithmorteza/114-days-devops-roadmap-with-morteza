# Day 025 – LPIC-3: Performance tuning II

## 🎯 Goals
- LPIC-3: Performance tuning II

## 🔧 Lab / Project
Stress test & benchmark (ab/hey, fio)

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
