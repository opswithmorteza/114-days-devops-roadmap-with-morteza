# Day 004 – Bash scripting I (loops, functions)

## 🎯 Goals
- Bash scripting I (loops, functions)

## 🔧 Lab / Project
Backup automation script

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
