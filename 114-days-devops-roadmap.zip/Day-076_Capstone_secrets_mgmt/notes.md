# Day 076 – Capstone secrets mgmt

## 🎯 Goals
- Capstone secrets mgmt

## 🔧 Lab / Project
Vault setup & policies

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
