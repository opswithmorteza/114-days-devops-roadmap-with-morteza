# Day 018 – LPIC-3: LDAP basics

## 🎯 Goals
- LPIC-3: LDAP basics

## 🔧 Lab / Project
OpenLDAP server; add users/groups

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
