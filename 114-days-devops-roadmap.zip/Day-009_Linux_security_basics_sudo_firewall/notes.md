# Day 009 – Linux security basics (sudo, firewall)

## 🎯 Goals
- Linux security basics (sudo, firewall)

## 🔧 Lab / Project
SSH key auth; ufw baseline policy

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
