# Day 071 – Capstone CI/CD pipeline

## 🎯 Goals
- Capstone CI/CD pipeline

## 🔧 Lab / Project
Build & test automation

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
