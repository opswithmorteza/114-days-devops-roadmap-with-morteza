# Day 044 – Ansible roles & handlers

## 🎯 Goals
- Ansible roles & handlers

## 🔧 Lab / Project
Role-based deployment

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
