# Day 040 – Jenkins advanced (agents/stages)

## 🎯 Goals
- Jenkins advanced (agents/stages)

## 🔧 Lab / Project
Pipeline with parallel stages

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
