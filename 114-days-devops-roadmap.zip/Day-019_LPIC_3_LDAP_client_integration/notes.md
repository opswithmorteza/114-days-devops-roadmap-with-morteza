# Day 019 – LPIC-3: LDAP client integration

## 🎯 Goals
- LPIC-3: LDAP client integration

## 🔧 Lab / Project
PAM/NSS auth against LDAP

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
