# Day 036 – Docker volumes & networks

## 🎯 Goals
- Docker volumes & networks

## 🔧 Lab / Project
Attach volume; custom network

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
