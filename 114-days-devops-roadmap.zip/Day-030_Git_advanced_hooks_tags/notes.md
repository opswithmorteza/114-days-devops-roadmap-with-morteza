# Day 030 – Git advanced (hooks, tags)

## 🎯 Goals
- Git advanced (hooks, tags)

## 🔧 Lab / Project
Pre-commit hook for linting

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
