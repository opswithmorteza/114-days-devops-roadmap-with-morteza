# Day 013 – Linux troubleshooting

## 🎯 Goals
- Linux troubleshooting

## 🔧 Lab / Project
Break & fix a service; document steps

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
