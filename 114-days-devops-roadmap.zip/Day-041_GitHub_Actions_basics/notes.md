# Day 041 – GitHub Actions basics

## 🎯 Goals
- GitHub Actions basics

## 🔧 Lab / Project
CI workflow for tests

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
