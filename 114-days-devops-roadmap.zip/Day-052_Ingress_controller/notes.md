# Day 052 – Ingress controller

## 🎯 Goals
- Ingress controller

## 🔧 Lab / Project
Nginx ingress routing

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
