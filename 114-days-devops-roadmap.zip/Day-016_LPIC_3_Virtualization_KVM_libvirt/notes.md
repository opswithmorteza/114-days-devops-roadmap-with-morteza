# Day 016 – LPIC-3: Virtualization (KVM/libvirt)

## 🎯 Goals
- LPIC-3: Virtualization (KVM/libvirt)

## 🔧 Lab / Project
Create a VM with cloud-init; manage via virsh

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
