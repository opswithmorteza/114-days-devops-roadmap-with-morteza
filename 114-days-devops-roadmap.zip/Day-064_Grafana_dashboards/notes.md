# Day 064 – Grafana dashboards

## 🎯 Goals
- Grafana dashboards

## 🔧 Lab / Project
Create service dashboard

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
