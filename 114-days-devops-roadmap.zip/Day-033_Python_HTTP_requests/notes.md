# Day 033 – Python HTTP (requests)

## 🎯 Goals
- Python HTTP (requests)

## 🔧 Lab / Project
API checker CLI

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
