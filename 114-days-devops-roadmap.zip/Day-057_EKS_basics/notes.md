# Day 057 – EKS basics

## 🎯 Goals
- EKS basics

## 🔧 Lab / Project
Create & connect to EKS

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
