# Project – Day 006

Describe the project, steps to run, and expected outcome.
