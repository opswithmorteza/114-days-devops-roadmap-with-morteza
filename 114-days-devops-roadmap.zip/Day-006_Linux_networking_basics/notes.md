# Day 006 – Linux networking basics

## 🎯 Goals
- Linux networking basics

## 🔧 Lab / Project
Static IP + connectivity tests (ping/ss/tcpdump)

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
