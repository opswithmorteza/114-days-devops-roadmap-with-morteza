# Day 020 – LPIC-3: DNS advanced (BIND)

## 🎯 Goals
- LPIC-3: DNS advanced (BIND)

## 🔧 Lab / Project
Authoritative zone & forwarders

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
