# Day 038 – Reverse proxy (nginx) with Compose

## 🎯 Goals
- Reverse proxy (nginx) with Compose

## 🔧 Lab / Project
Nginx reverse proxy in front of app

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
