# Day 067 – Vault + Kubernetes

## 🎯 Goals
- Vault + Kubernetes

## 🔧 Lab / Project
Inject secrets to pods

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
