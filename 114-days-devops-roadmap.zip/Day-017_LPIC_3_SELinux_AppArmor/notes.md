# Day 017 – LPIC-3: SELinux/AppArmor

## 🎯 Goals
- LPIC-3: SELinux/AppArmor

## 🔧 Lab / Project
Constrain nginx with AppArmor/SELinux

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
