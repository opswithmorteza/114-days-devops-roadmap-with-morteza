# Day 037 – Docker Compose basics

## 🎯 Goals
- Docker Compose basics

## 🔧 Lab / Project
App + DB stack

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
