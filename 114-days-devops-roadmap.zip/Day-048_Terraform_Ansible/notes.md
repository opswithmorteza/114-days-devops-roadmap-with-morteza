# Day 048 – Terraform + Ansible

## 🎯 Goals
- Terraform + Ansible

## 🔧 Lab / Project
IaC → Provision → Configure

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
