# Day 050 – K8s services & deployments

## 🎯 Goals
- K8s services & deployments

## 🔧 Lab / Project
Expose service; rolling update

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
