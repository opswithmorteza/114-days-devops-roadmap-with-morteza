# Day 080 – Capstone docs

## 🎯 Goals
- Capstone docs

## 🔧 Lab / Project
README + wiki

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
