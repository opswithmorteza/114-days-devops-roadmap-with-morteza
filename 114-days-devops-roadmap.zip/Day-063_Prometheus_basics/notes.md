# Day 063 – Prometheus basics

## 🎯 Goals
- Prometheus basics

## 🔧 Lab / Project
Scrape metrics

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
