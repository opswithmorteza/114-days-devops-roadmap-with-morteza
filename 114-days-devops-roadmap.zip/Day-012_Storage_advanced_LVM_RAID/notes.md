# Day 012 – Storage advanced (LVM, RAID)

## 🎯 Goals
- Storage advanced (LVM, RAID)

## 🔧 Lab / Project
Create LVM VG/LV; snapshot & restore

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
