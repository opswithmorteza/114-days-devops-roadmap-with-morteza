# Day 024 – LPIC-3: Performance tuning I

## 🎯 Goals
- LPIC-3: Performance tuning I

## 🔧 Lab / Project
Use htop/iotop/sar; tune sysctl

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
