# Day 061 – ELK Stack basics

## 🎯 Goals
- ELK Stack basics

## 🔧 Lab / Project
Centralized logging stack

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
