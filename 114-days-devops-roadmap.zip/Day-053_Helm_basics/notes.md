# Day 053 – Helm basics

## 🎯 Goals
- Helm basics

## 🔧 Lab / Project
Package app with Helm

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
