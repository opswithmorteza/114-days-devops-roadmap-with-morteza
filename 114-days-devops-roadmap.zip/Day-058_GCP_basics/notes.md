# Day 058 – GCP basics

## 🎯 Goals
- GCP basics

## 🔧 Lab / Project
Create GKE cluster

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
