# Day 043 – Ansible basics

## 🎯 Goals
- Ansible basics

## 🔧 Lab / Project
Install nginx on 2 VMs

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
