# Project – Day 003

Describe the project, steps to run, and expected outcome.
