# Day 003 – Shell basics (pipes, redirection)

## 🎯 Goals
- Shell basics (pipes, redirection)

## 🔧 Lab / Project
Write a log filter script

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
