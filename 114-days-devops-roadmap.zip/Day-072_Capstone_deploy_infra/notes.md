# Day 072 – Capstone deploy infra

## 🎯 Goals
- Capstone deploy infra

## 🔧 Lab / Project
Terraform + Ansible

## 📝 Notes
- Commands tried:
- Gotchas:

## 🔎 References
- Add official docs and high-quality links you used.
